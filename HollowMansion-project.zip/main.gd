extends Node3D
## The Hollow Mansion - a Gorilla Tag-style horror game.
## Find 3 keys, unlock the front door, run outside. Don't make noise.

const KEYS_NEEDED := 3

var mansion: Mansion
var player: GorillaPlayer
var monster: Monster
var keys: Array[Node3D] = []
var keys_found := 0
var unlocked := false
var finished := false
var _hud_t := 0.0
var _spawn := Vector3.ZERO
var _xr := false


func _ready() -> void:
	_setup_xr()
	_setup_environment()

	mansion = Mansion.new()
	add_child(mansion)
	mansion.build()
	_spawn = mansion.player_spawn()

	player = GorillaPlayer.new()
	player.xr_active = _xr
	player.position = _spawn
	add_child(player)

	monster = Monster.new()
	add_child(monster)
	monster.setup(mansion.spawn_path(), mansion.loop_points(), player)
	monster.caught.connect(_on_caught)

	# Every hard hand slap on a surface makes noise the Hollow can hear.
	player.hand_slap.connect(func(pos: Vector3, strength: float) -> void:
		monster.hear(pos, clampf(4.0 + strength * 2.0, 4.0, 16.0)))

	_spawn_keys()
	_update_hud()
	player.show_message("Find 3 keys.\nThe front door is locked.\nSlapping walls makes noise...", 7.0)


func _setup_xr() -> void:
	var xr := XRServer.find_interface("OpenXR")
	if xr and xr.is_initialized():
		get_viewport().use_xr = true
		_xr = true
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)


func _setup_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.02, 0.02, 0.05)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.32, 0.34, 0.45)
	env.ambient_light_energy = 0.7
	env.fog_enabled = true
	env.fog_light_color = Color(0.05, 0.05, 0.08)
	env.fog_density = 0.015
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var moon := DirectionalLight3D.new()
	moon.light_color = Color(0.5, 0.6, 0.9)
	moon.light_energy = 0.25
	moon.rotation_degrees = Vector3(-50, 30, 0)
	add_child(moon)


func _spawn_keys() -> void:
	var gold := StandardMaterial3D.new()
	gold.albedo_color = Color(1.0, 0.82, 0.3)
	gold.emission_enabled = true
	gold.emission = Color(1.0, 0.82, 0.3)
	gold.emission_energy_multiplier = 1.5
	for p in mansion.key_positions():
		var key := Node3D.new()
		key.position = p
		var shaft := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.16, 0.03, 0.03)
		shaft.mesh = bm
		shaft.material_override = gold
		key.add_child(shaft)
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 0.025
		tm.outer_radius = 0.05
		tm.rings = 10
		tm.ring_segments = 6
		ring.mesh = tm
		ring.material_override = gold
		ring.position = Vector3(-0.1, 0, 0)
		ring.rotation_degrees = Vector3(90, 0, 0)
		key.add_child(ring)
		var glow := OmniLight3D.new()
		glow.light_color = Color(1.0, 0.85, 0.4)
		glow.light_energy = 0.6
		glow.omni_range = 2.5
		key.add_child(glow)
		add_child(key)
		keys.append(key)


func _process(delta: float) -> void:
	for key in keys:
		key.rotate_y(delta * 1.5)
	mansion.flicker(delta, monster.global_position)

	# pick up keys by touching them with a hand
	for key in keys.duplicate():
		var kp: Vector3 = key.global_position
		if kp.distance_to(player.left_follower.global_position) < 0.3 or kp.distance_to(player.right_follower.global_position) < 0.3 \
				or kp.distance_to(player.left_hand.global_position) < 0.3 or kp.distance_to(player.right_hand.global_position) < 0.3:
			keys.erase(key)
			key.queue_free()
			keys_found += 1
			player.flash(Color(1.0, 0.85, 0.3), 0.5)
			if keys_found >= KEYS_NEEDED:
				_unlock()
			else:
				player.show_message("Key %d of %d" % [keys_found, KEYS_NEEDED], 2.0)

	if unlocked and not finished and player.global_position.z > 7.5:
		finished = true
		player.flash(Color(1, 1, 1), 2.0)
		player.show_message("YOU ESCAPED!", 8.0)
		get_tree().create_timer(9.0).timeout.connect(func() -> void: get_tree().reload_current_scene())

	_hud_t -= delta
	if _hud_t <= 0.0:
		_hud_t = 0.4
		_update_hud()


func _unlock() -> void:
	unlocked = true
	if is_instance_valid(mansion.front_door):
		mansion.front_door.queue_free()
	player.show_message("The front door is open.\nRUN!", 5.0)


func _update_hud() -> void:
	var goal := "Run outside!" if unlocked else "Find the keys"
	player.set_hud("Keys %d/%d\n%s\nHollow: %s" % [keys_found, KEYS_NEEDED, goal, monster.state_text()])


func _on_caught() -> void:
	if finished:
		return
	player.flash(Color(0.55, 0, 0), 1.5)
	player.show_message("THE HOLLOW GOT YOU", 3.0)
	player.teleport_to(_spawn)
	monster.reset_far_from(_spawn)
