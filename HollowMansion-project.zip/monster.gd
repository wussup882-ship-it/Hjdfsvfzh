class_name Monster
extends Node3D
## The Hollow. Tall, thin, eyeless. It walks a loop through the ground floor,
## walks to noises you make (slapping surfaces), and runs at you if it sees you.

signal caught

enum St { SPAWN, PATROL, INVESTIGATE, SEARCH, HUNT }

var st: St = St.SPAWN
var spawn_path: Array[Vector3] = []
var loop: Array[Vector3] = []
var player: GorillaPlayer

var k := 0              # index of the waypoint we are walking to
var target_k := 0       # waypoint we are investigating
var speed := 0.0
var wait := 0.0
var t := 0.0
var phase := 0.0
var yaw := 0.0
var seeing := false
var lost_time := 0.0
var last_seen := Vector3.ZERO
var view_dist := 13.0
var noise_name := ""

var grace := 0.0         # seconds after a respawn where it can't see you
var _sense_t := 0.0
var _torso: Node3D
var _head: Node3D
var _mb: Node3D
var _legs: Array = []
var _arms: Array = []
var _light: OmniLight3D
var _dark: StandardMaterial3D
var _pale: StandardMaterial3D


func _ready() -> void:
	_build()


func setup(spawn: Array[Vector3], loop_pts: Array[Vector3], p: GorillaPlayer) -> void:
	spawn_path = spawn
	loop = loop_pts
	player = p
	global_position = spawn[0]
	st = St.SPAWN
	k = 0


## After it catches you: put it on the loop point farthest from `away_from`
## and give you a few seconds of peace.
func reset_far_from(away_from: Vector3) -> void:
	var best := 0
	var bd := -1.0
	for i in loop.size():
		var d := Vector2(loop[i].x - away_from.x, loop[i].z - away_from.z).length_squared()
		if d > bd:
			bd = d
			best = i
	st = St.PATROL
	k = best
	global_position = loop[best]
	speed = 0.0
	seeing = false
	lost_time = 0.0
	grace = 6.0


func state_text() -> String:
	match st:
		St.SPAWN: return "waking"
		St.PATROL: return "patrolling"
		St.INVESTIGATE: return "heard something"
		St.SEARCH: return "searching"
		St.HUNT: return "hunting"
	return ""


# ---------------------------------------------------------------- the model

func _part(parent: Node3D, size: Vector3, pos: Vector3, m: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi


func _limb(parent: Node3D, pos: Vector3, length: float, thick: float, m: Material) -> Node3D:
	var g := Node3D.new()
	g.position = pos
	parent.add_child(g)
	_part(g, Vector3(thick, length, thick), Vector3(0, -length / 2.0, 0), m)
	return g


func _build() -> void:
	_dark = StandardMaterial3D.new()
	_dark.albedo_color = Color.hex(0x1d1b22ff)
	_pale = StandardMaterial3D.new()
	_pale.albedo_color = Color.hex(0xd9d6c9ff)
	_mb = Node3D.new()
	_mb.scale = Vector3.ONE * 0.88
	add_child(_mb)
	_torso = Node3D.new()
	_torso.position = Vector3(0, 1.2, 0)
	_mb.add_child(_torso)
	_head = Node3D.new()
	_head.position = Vector3(0, 1.12, 0)
	_torso.add_child(_head)

	for x in [-0.12, 0.12]:
		var upper := _limb(_mb, Vector3(x, 1.2, 0), 0.6, 0.1, _dark)
		var lower := _limb(upper, Vector3(0, -0.6, 0), 0.6, 0.09, _dark)
		_part(lower, Vector3(0.12, 0.05, 0.26), Vector3(0, -0.6, 0.08), _dark)
		_legs.append([upper, lower])
	for x in [-0.29, 0.29]:
		var upper := _limb(_torso, Vector3(x, 0.85, 0), 0.75, 0.08, _dark)
		var lower := _limb(upper, Vector3(0, -0.75, 0), 0.8, 0.07, _dark)
		var fingers := Node3D.new()
		fingers.position = Vector3(0, -0.8, 0)
		lower.add_child(fingers)
		for i in [-1, 0, 1]:
			_part(fingers, Vector3(0.02, 0.3, 0.02), Vector3(i * 0.035, -0.15, 0), _pale)
		_arms.append([upper, lower, fingers])

	_part(_torso, Vector3(0.42, 0.9, 0.24), Vector3(0, 0.45, 0), _dark)
	_part(_torso, Vector3(0.08, 0.25, 0.08), Vector3(0, 1.0, 0), _dark)
	var hm := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.17
	sm.height = 0.34
	sm.radial_segments = 12
	sm.rings = 6
	hm.mesh = sm
	hm.material_override = _pale
	hm.scale = Vector3(0.85, 1.7, 0.85)
	hm.position = Vector3(0, 0.2, 0)
	_head.add_child(hm)
	_part(_head, Vector3(0.03, 0.2, 0.02), Vector3(0, 0.12, 0.14), _dark)   # the mouth slit

	_light = OmniLight3D.new()
	_light.light_color = Color(1.0, 0.2, 0.13)
	_light.light_energy = 0.5
	_light.omni_range = 7.0
	_light.position = Vector3(0, 1.8, 0)
	add_child(_light)


# --------------------------------------------------------------- behaviour

func _nearest(p: Vector3) -> int:
	var best := 0
	var bd := INF
	for i in loop.size():
		var d := Vector2(loop[i].x - p.x, loop[i].z - p.z).length_squared()
		if d < bd:
			bd = d
			best = i
	return best


## Something made a noise at pos that can be heard within `radius` metres.
func hear(pos: Vector3, radius: float) -> void:
	if loop.is_empty() or st == St.SPAWN or st == St.HUNT:
		return
	if global_position.distance_to(pos) > radius:
		return
	target_k = _nearest(pos)
	if st != St.INVESTIGATE:
		k = _nearest(global_position)
	st = St.INVESTIGATE


func _sense(delta: float) -> void:
	if player == null or st == St.SPAWN:
		return
	if grace > 0.0:
		grace -= delta
		seeing = false
		return
	_sense_t -= delta
	if _sense_t > 0.0:
		return
	_sense_t = 0.15
	var eyes := global_position + Vector3(0, 2.0, 0)
	var pp := player.head_position()
	var flat := Vector3(pp.x - eyes.x, 0, pp.z - eyes.z)
	var can_see := false
	if eyes.distance_to(pp) < view_dist:
		var forward := Vector3(sin(yaw), 0, cos(yaw))
		if flat.length() < 2.0 or forward.dot(flat.normalized()) > -0.2:
			var q := PhysicsRayQueryParameters3D.create(eyes, pp, 1)
			can_see = get_world_3d().direct_space_state.intersect_ray(q).is_empty()
	seeing = can_see
	if can_see:
		last_seen = pp
		lost_time = 0.0
		st = St.HUNT
	elif st == St.HUNT:
		lost_time += 0.15
		if lost_time > 0.8:
			st = St.INVESTIGATE
			k = _nearest(global_position)
			target_k = _nearest(last_seen)


func _step_toward(tp: Vector3, delta: float) -> bool:
	var v := tp - global_position
	var dist := v.length()
	var step := speed * delta
	if dist <= step + 0.01:
		global_position = tp
		return true
	v = v / dist * step
	global_position += v
	if Vector2(v.x, v.z).length() > 0.0001:
		yaw = lerp_angle(yaw, atan2(v.x, v.z), minf(1.0, delta * 6.0))
		rotation.y = yaw
	return false


func _physics_process(delta: float) -> void:
	if loop.is_empty():
		return
	t += delta
	_sense(delta)
	var goal := 0.0
	var tp := global_position
	var moving := false
	match st:
		St.SPAWN:
			tp = spawn_path[k]
			goal = 1.6
			moving = true
		St.PATROL:
			tp = loop[k]
			goal = 1.3
			moving = true
		St.INVESTIGATE:
			tp = loop[k]
			goal = 2.6
			moving = true
		St.SEARCH:
			wait -= delta
			if wait <= 0.0:
				st = St.PATROL
				k = _nearest(global_position)
		St.HUNT:
			goal = 4.6
			tp = Vector3(last_seen.x, global_position.y, last_seen.z)
			moving = true

	speed += (goal - speed) * minf(1.0, delta * 4.0)
	if moving and _step_toward(tp, delta):
		_arrived()
	_check_catch()
	_animate(delta)


func _arrived() -> void:
	match st:
		St.SPAWN:
			k += 1
			if k >= spawn_path.size():
				st = St.PATROL
				k = _nearest(global_position)
		St.PATROL:
			k = (k + 1) % loop.size()
		St.INVESTIGATE:
			if k == target_k:
				st = St.SEARCH
				wait = 3.5
			else:
				k = (k + 1) % loop.size()


func _check_catch() -> void:
	if st != St.HUNT or player == null:
		return
	var pp := player.head_position()
	var flat := Vector2(pp.x - global_position.x, pp.z - global_position.z).length()
	var dy := pp.y - global_position.y
	if flat < 1.0 and dy > -0.5 and dy < 2.8:
		st = St.SEARCH
		wait = 4.0
		caught.emit()


# --------------------------------------------------------------- animation

func _animate(delta: float) -> void:
	var a := minf(1.0, speed / 1.4)
	var rn := clampf((speed - 2.0) / 2.5, 0.0, 1.0)
	phase += speed * delta * 2.4
	var s := sin(phase)
	var sw := [-s, s]
	_legs[0][0].rotation.x = s * 0.6 * a
	_legs[1][0].rotation.x = -s * 0.6 * a
	_legs[0][1].rotation.x = maxf(0.0, -s) * 0.8 * a
	_legs[1][1].rotation.x = maxf(0.0, s) * 0.8 * a
	for i in 2:
		var r: Array = _arms[i]
		r[0].rotation.x = (sw[i] * 0.5 * a - 0.15) * (1.0 - rn) + (-1.1 + sw[i] * 0.3) * rn
		r[1].rotation.x = -0.35 - 0.25 * a
		r[2].rotation.x = sin(t * 9.0 + i * 2.0) * 0.25 * (1.0 + rn)
	_torso.rotation.x = 0.1 + 0.35 * rn + sin(t * 1.4) * 0.02
	_head.rotation.x = 0.15 + 0.2 * rn
	_head.rotation.z = sin(t * 0.9) * 0.14
	_head.rotation.y = sin(t * 2.2) * 0.9 if st == St.SEARCH else sin(t * 0.7) * 0.25
	_mb.position.y = absf(s) * 0.06 * a
	_light.light_energy = 0.5 + rn * 1.2 + sin(t * 3.0) * 0.1
