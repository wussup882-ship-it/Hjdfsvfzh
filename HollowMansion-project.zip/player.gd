class_name GorillaPlayer
extends CharacterBody3D
## Godot 4.4 port of the Unity "GorillaLocomotion" Player.cs you sent.
## The algorithm and all tuning numbers are copied from that package and its
## "Gorilla Rig" prefab. The Rigidbody becomes a CharacterBody3D (velocity +
## gravity + move_and_slide), and Unity's Physics.SphereCast / Raycast become
## PhysicsDirectSpaceState3D queries.
##
## The VR rig is built here in code:
##   GorillaPlayer
##   ├── XROrigin3D
##   │   ├── XRCamera3D          (headCollider follows this)
##   │   ├── XRController3D left_hand / right_hand
##   ├── head collider (sphere r 0.15) and body collider (capsule r 0.15, h 0.5)
##   └── two hand "follower" orbs (the visible hands, they stick to surfaces)

signal hand_slap(pos: Vector3, strength: float)

# ---- values from the Unity "Gorilla Rig" prefab -------------------------
@export var velocity_history_size := 8
@export var max_arm_length := 1.5
@export var un_stick_distance := 1.0
@export var velocity_limit := 0.4
@export var max_jump_speed := 6.5
@export var jump_multiplier := 1.1
@export var minimum_raycast_distance := 0.05
@export var default_slide_factor := 0.03
@export var default_precision := 0.995
@export var right_hand_offset := Vector3.ZERO
@export var left_hand_offset := Vector3.ZERO
@export_flags_3d_physics var locomotion_layers := 1
@export var disable_movement := false
# ---- extras that are not in the Unity package ---------------------------
## A Unity Rigidbody gets friction from its physics material. CharacterBody3D
## has none, so this slows you down when your body lands on a floor.
@export var ground_friction := 10.0
@export var snap_turn_degrees := 30.0

const HEAD_RADIUS := 0.15
const GRAVITY := 9.8

var xr_active := false

var origin: XROrigin3D
var camera: XRCamera3D
var left_hand: XRController3D
var right_hand: XRController3D
var left_follower: MeshInstance3D
var right_follower: MeshInstance3D

var was_left_hand_touching := false
var was_right_hand_touching := false

var last_left_hand_position := Vector3.ZERO
var last_right_hand_position := Vector3.ZERO
var last_head_position := Vector3.ZERO
var last_position := Vector3.ZERO

var _velocity_history: Array[Vector3] = []
var _velocity_index := 0
var _current_velocity := Vector3.ZERO
var _denormalized_velocity_average := Vector3.ZERO

var _space: PhysicsDirectSpaceState3D
var _head_shape: CollisionShape3D
var _body_shape: CollisionShape3D
var _inited := false
var _turned := false
var _hud: Label3D
var _msg: Label3D
var _msg_id := 0
var _overlay: MeshInstance3D


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING

	origin = XROrigin3D.new()
	add_child(origin)
	camera = XRCamera3D.new()
	origin.add_child(camera)
	left_hand = _make_hand(&"left_hand")
	right_hand = _make_hand(&"right_hand")
	if not xr_active:
		# Not in a headset (editor / tests): park the head and hands somewhere sensible.
		camera.position = Vector3(0, 1.6, 0)
		left_hand.position = Vector3(-0.25, 1.2, -0.3)
		right_hand.position = Vector3(0.25, 1.2, -0.3)

	_head_shape = CollisionShape3D.new()
	var hs := SphereShape3D.new()
	hs.radius = HEAD_RADIUS
	_head_shape.shape = hs
	add_child(_head_shape)
	_body_shape = CollisionShape3D.new()
	var bs := CapsuleShape3D.new()
	bs.radius = 0.15
	bs.height = 0.5
	_body_shape.shape = bs
	add_child(_body_shape)

	left_follower = _make_orb(Color(0.85, 0.85, 0.8))
	right_follower = _make_orb(Color(0.85, 0.85, 0.8))

	_build_hud()
	_velocity_history.resize(maxi(velocity_history_size, 1))
	_velocity_history.fill(Vector3.ZERO)


func _make_hand(tracker_name: StringName) -> XRController3D:
	var h := XRController3D.new()
	h.tracker = tracker_name
	origin.add_child(h)
	return h


func _make_orb(c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.06
	sm.height = 0.12
	sm.radial_segments = 12
	sm.rings = 6
	mi.mesh = sm
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	mi.material_override = m
	mi.top_level = true
	add_child(mi)
	return mi


func _build_hud() -> void:
	_hud = Label3D.new()
	_hud.font_size = 40
	_hud.pixel_size = 0.0012
	_hud.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_hud.position = Vector3(0, 0.1, 0)
	_hud.outline_size = 8
	left_hand.add_child(_hud)

	_msg = Label3D.new()
	_msg.font_size = 56
	_msg.pixel_size = 0.0011
	_msg.position = Vector3(0, 0.1, -1.1)
	_msg.no_depth_test = true
	_msg.render_priority = 110
	_msg.outline_render_priority = 109
	_msg.outline_size = 12
	_msg.visible = false
	camera.add_child(_msg)

	_overlay = MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(3, 3)
	_overlay.mesh = qm
	var om := StandardMaterial3D.new()
	om.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	om.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	om.albedo_color = Color(0, 0, 0, 0)
	om.no_depth_test = true
	om.render_priority = 100
	_overlay.material_override = om
	_overlay.position = Vector3(0, 0, -0.3)
	camera.add_child(_overlay)


# ---------------------------------------------------------------- HUD helpers

func set_hud(text: String) -> void:
	_hud.text = text


func show_message(text: String, secs: float) -> void:
	_msg_id += 1
	var id := _msg_id
	_msg.text = text
	_msg.visible = true
	get_tree().create_timer(secs).timeout.connect(func() -> void:
		if id == _msg_id:
			_msg.visible = false)


func flash(c: Color, secs: float) -> void:
	var m := _overlay.material_override as StandardMaterial3D
	m.albedo_color = Color(c.r, c.g, c.b, 0.85)
	var tw := create_tween()
	tw.tween_property(m, "albedo_color:a", 0.0, secs)


func head_position() -> Vector3:
	return camera.global_position


func teleport_to(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	_inited = false


# ----------------------------------------------------------- Unity: Awake etc

func _initialize_values() -> void:
	# InitializeValues()
	_velocity_history.fill(Vector3.ZERO)
	_denormalized_velocity_average = Vector3.ZERO
	last_left_hand_position = left_hand.global_position
	last_right_hand_position = right_hand.global_position
	last_head_position = camera.global_position
	_velocity_index = 0
	last_position = global_position
	was_left_hand_touching = false
	was_right_hand_touching = false


func _current_left_hand_position() -> Vector3:
	return _clamped_hand(left_hand, left_hand_offset)


func _current_right_hand_position() -> Vector3:
	return _clamped_hand(right_hand, right_hand_offset)


func _clamped_hand(hand: Node3D, offset: Vector3) -> Vector3:
	var head := camera.global_position
	var p := _position_with_offset(hand, offset)
	if (p - head).length() < max_arm_length:
		return p
	return head + (p - head).normalized() * max_arm_length


func _position_with_offset(t: Node3D, offset: Vector3) -> Vector3:
	return t.global_position + t.global_transform.basis.orthonormalized() * offset


# ------------------------------------------------- Unity: Physics queries

## Physics.SphereCast: returns {} when nothing is hit. Like Unity, colliders the
## sphere already overlaps at the start are ignored.
func _sphere_cast(origin_pos: Vector3, radius: float, direction: Vector3, max_dist: float) -> Dictionary:
	if direction.length() < 0.00001 or max_dist <= 0.0:
		return {}
	var dir := direction.normalized()
	var sh := SphereShape3D.new()
	sh.radius = maxf(radius, 0.001)
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = sh
	q.collision_mask = locomotion_layers
	q.transform = Transform3D(Basis.IDENTITY, origin_pos)
	var ex: Array[RID] = [get_rid()]
	q.exclude = ex
	for o in _space.intersect_shape(q, 16):
		ex.append(o["rid"])
	q.exclude = ex
	q.motion = dir * max_dist
	var r := _space.cast_motion(q)
	if r.size() < 2 or r[1] >= 1.0:
		return {}
	var safe_dist: float = max_dist * float(r[0])
	var hit_pos := origin_pos + dir * max_dist * float(r[1])
	q.transform = Transform3D(Basis.IDENTITY, hit_pos)
	q.motion = Vector3.ZERO
	var info := _space.get_rest_info(q)
	if info.is_empty():
		return {"distance": safe_dist, "point": origin_pos + dir * (safe_dist + radius), "normal": -dir}
	var n: Vector3 = info["normal"]
	if n.length() < 0.001:
		n = -dir
	return {"distance": safe_dist, "point": info["point"], "normal": n.normalized(), "collider": instance_from_id(int(info["collider_id"]))}


## Physics.Raycast
func _raycast(start: Vector3, direction: Vector3, max_dist: float) -> Dictionary:
	if direction.length() < 0.00001 or max_dist <= 0.0:
		return {}
	var q := PhysicsRayQueryParameters3D.create(start, start + direction.normalized() * max_dist, locomotion_layers)
	var ex: Array[RID] = [get_rid()]
	q.exclude = ex
	var r := _space.intersect_ray(q)
	if r.is_empty():
		return {}
	return {"distance": start.distance_to(r["position"]), "point": r["position"], "normal": r["normal"], "collider": r["collider"]}


# --------------------------------- Unity: CollisionsSphereCast / Iterative...

func _collisions_sphere_cast(start: Vector3, sphere_radius: float, move: Vector3, precision: float) -> Dictionary:
	var info := _sphere_cast(start, sphere_radius * precision, move, move.length() + sphere_radius * (1.0 - precision))
	if not info.is_empty():
		var final_pos: Vector3 = info["point"] + info["normal"] * sphere_radius
		var to_final := final_pos - start
		var inner := _sphere_cast(start, sphere_radius * precision * precision, to_final, to_final.length() + sphere_radius * (1.0 - precision * precision))
		if not inner.is_empty():
			final_pos = start + to_final.normalized() * maxf(0.0, float(info["distance"]) - sphere_radius * (1.0 - precision * precision))
			info = inner
		else:
			var ray := _raycast(start, to_final, to_final.length() + sphere_radius * precision * precision * 0.999)
			if not ray.is_empty():
				return {"hit": true, "pos": start, "info": ray}
		return {"hit": true, "pos": final_pos, "info": info}
	var ray2 := _raycast(start, move, move.length() + sphere_radius * precision * 0.999)
	if not ray2.is_empty():
		return {"hit": true, "pos": start, "info": ray2}
	return {"hit": false, "pos": Vector3.ZERO, "info": {}}


func _iterative_collision_sphere_cast(start: Vector3, sphere_radius: float, move: Vector3, precision: float, single_hand: bool) -> Dictionary:
	var c := _collisions_sphere_cast(start, sphere_radius * precision, move, precision)
	if c["hit"]:
		var first_position: Vector3 = c["pos"]
		var info: Dictionary = c["info"]
		var slip := 0.001 if single_hand else default_slide_factor
		var collider: Object = info.get("collider")
		if collider != null and collider.has_meta("slip_percentage"):
			slip = float(collider.get_meta("slip_percentage"))
		var normal: Vector3 = info["normal"]
		var slide := (start + move - first_position).slide(normal) * slip
		var c2 := _collisions_sphere_cast(first_position, sphere_radius, slide, precision * precision)
		if c2["hit"]:
			return {"hit": true, "end": c2["pos"]}
		var from := slide + first_position
		var c3 := _collisions_sphere_cast(from, sphere_radius, start + move - from, precision * precision * precision)
		if c3["hit"]:
			return {"hit": true, "end": c3["pos"]}
		return {"hit": true, "end": first_position}
	var c4 := _collisions_sphere_cast(start, sphere_radius * precision * 0.66, move.normalized() * (move.length() + sphere_radius * precision * 0.34), precision * 0.66)
	if c4["hit"]:
		return {"hit": true, "end": start}
	return {"hit": false, "end": Vector3.ZERO}


# ---------------------------------------------------------- Unity: Update()

func _physics_process(delta: float) -> void:
	_space = get_world_3d().direct_space_state
	_sync_colliders()
	if not _inited:
		_initialize_values()
		_inited = true
		return
	_snap_turn_input()
	_update_locomotion(delta)
	velocity.y -= GRAVITY * delta   # Rigidbody gravity
	move_and_slide()
	_apply_ground_friction(delta)


func _sync_colliders() -> void:
	var head := camera.global_position
	_head_shape.global_position = head
	var f := -camera.global_transform.basis.z
	var yaw := atan2(-f.x, -f.z)
	var yaw_basis := Basis(Vector3.UP, yaw)
	# Unity: capsule at (0, -0.24, -0.06) in head space (Unity forward is +z, Godot forward is -z)
	_body_shape.global_transform = Transform3D(yaw_basis, head + yaw_basis * Vector3(0, -0.24, 0.06))


func _update_locomotion(delta: float) -> void:
	var left_colliding := false
	var right_colliding := false
	var rigid_body_movement := Vector3.ZERO
	var first_iteration_left := Vector3.ZERO
	var first_iteration_right := Vector3.ZERO
	var gravity_nudge := Vector3.DOWN * 2.0 * GRAVITY * delta * delta

	# ---- left hand
	var distance_traveled := _current_left_hand_position() - last_left_hand_position + gravity_nudge
	var r := _iterative_collision_sphere_cast(last_left_hand_position, minimum_raycast_distance, distance_traveled, default_precision, true)
	if r["hit"]:
		if was_left_hand_touching:
			first_iteration_left = last_left_hand_position - _current_left_hand_position()
		else:
			first_iteration_left = r["end"] - _current_left_hand_position()
			_maybe_slap(left_follower, last_left_hand_position, _current_left_hand_position(), delta)
		velocity = Vector3.ZERO
		left_colliding = true

	# ---- right hand
	distance_traveled = _current_right_hand_position() - last_right_hand_position + gravity_nudge
	r = _iterative_collision_sphere_cast(last_right_hand_position, minimum_raycast_distance, distance_traveled, default_precision, true)
	if r["hit"]:
		if was_right_hand_touching:
			first_iteration_right = last_right_hand_position - _current_right_hand_position()
		else:
			first_iteration_right = r["end"] - _current_right_hand_position()
			_maybe_slap(right_follower, last_right_hand_position, _current_right_hand_position(), delta)
		velocity = Vector3.ZERO
		right_colliding = true

	# ---- average or add
	if (left_colliding or was_left_hand_touching) and (right_colliding or was_right_hand_touching):
		rigid_body_movement = (first_iteration_left + first_iteration_right) / 2.0
	else:
		rigid_body_movement = first_iteration_left + first_iteration_right

	# ---- check valid head movement
	var head_now := camera.global_position
	r = _iterative_collision_sphere_cast(last_head_position, HEAD_RADIUS, head_now + rigid_body_movement - last_head_position, default_precision, false)
	if r["hit"]:
		rigid_body_movement = r["end"] - last_head_position
		var d := head_now - last_head_position + rigid_body_movement
		var ray := _raycast(last_head_position, d, d.length() + HEAD_RADIUS * default_precision * 0.999)
		if not ray.is_empty():
			rigid_body_movement = last_head_position - head_now

	if rigid_body_movement != Vector3.ZERO:
		global_position = global_position + rigid_body_movement

	last_head_position = camera.global_position

	# ---- final left hand position
	distance_traveled = _current_left_hand_position() - last_left_hand_position
	var both := (left_colliding or was_left_hand_touching) and (right_colliding or was_right_hand_touching)
	r = _iterative_collision_sphere_cast(last_left_hand_position, minimum_raycast_distance, distance_traveled, default_precision, not both)
	if r["hit"]:
		last_left_hand_position = r["end"]
		left_colliding = true
	else:
		last_left_hand_position = _current_left_hand_position()

	# ---- final right hand position
	distance_traveled = _current_right_hand_position() - last_right_hand_position
	both = (left_colliding or was_left_hand_touching) and (right_colliding or was_right_hand_touching)
	r = _iterative_collision_sphere_cast(last_right_hand_position, minimum_raycast_distance, distance_traveled, default_precision, not both)
	if r["hit"]:
		last_right_hand_position = r["end"]
		right_colliding = true
	else:
		last_right_hand_position = _current_right_hand_position()

	_store_velocities(delta)

	if (right_colliding or left_colliding) and not disable_movement:
		if _denormalized_velocity_average.length() > velocity_limit:
			if _denormalized_velocity_average.length() * jump_multiplier > max_jump_speed:
				velocity = _denormalized_velocity_average.normalized() * max_jump_speed
			else:
				velocity = jump_multiplier * _denormalized_velocity_average

	# ---- unstick left hand
	var head := camera.global_position
	var cur_left := _current_left_hand_position()
	if left_colliding and (cur_left - last_left_hand_position).length() > un_stick_distance \
			and _sphere_cast(head, minimum_raycast_distance * default_precision, cur_left - head, (cur_left - head).length() - minimum_raycast_distance).is_empty():
		last_left_hand_position = cur_left
		left_colliding = false

	# ---- unstick right hand
	var cur_right := _current_right_hand_position()
	if right_colliding and (cur_right - last_right_hand_position).length() > un_stick_distance \
			and _sphere_cast(head, minimum_raycast_distance * default_precision, cur_right - head, (cur_right - head).length() - minimum_raycast_distance).is_empty():
		last_right_hand_position = cur_right
		right_colliding = false

	left_follower.global_position = last_left_hand_position
	right_follower.global_position = last_right_hand_position

	was_left_hand_touching = left_colliding
	was_right_hand_touching = right_colliding


func _store_velocities(delta: float) -> void:
	# StoreVelocities()
	_velocity_index = (_velocity_index + 1) % _velocity_history.size()
	var oldest := _velocity_history[_velocity_index]
	_current_velocity = (global_position - last_position) / delta
	_denormalized_velocity_average += (_current_velocity - oldest) / float(_velocity_history.size())
	_velocity_history[_velocity_index] = _current_velocity
	last_position = global_position


func is_hand_touching(for_left_hand: bool) -> bool:
	return was_left_hand_touching if for_left_hand else was_right_hand_touching


## Unity: Turn(degrees). Positive = turn right.
func turn(degrees: float) -> void:
	var a := -deg_to_rad(degrees)
	var q := Basis(Vector3.UP, a)
	var head := camera.global_position
	global_transform = Transform3D(q, head - q * head) * global_transform
	_denormalized_velocity_average = q * _denormalized_velocity_average
	for i in _velocity_history.size():
		_velocity_history[i] = q * _velocity_history[i]


func _snap_turn_input() -> void:
	var s := right_hand.get_vector2(&"primary")
	if absf(s.x) > 0.7 and not _turned:
		turn(signf(s.x) * snap_turn_degrees)
		_turned = true
	elif absf(s.x) < 0.3:
		_turned = false


# ----------------------------------------------------------------- extras

func _maybe_slap(_follower: Node3D, from: Vector3, to: Vector3, delta: float) -> void:
	var speed := from.distance_to(to) / maxf(delta, 0.0001)
	if speed > 1.5:
		hand_slap.emit(to, speed)


func _apply_ground_friction(delta: float) -> void:
	for i in get_slide_collision_count():
		if get_slide_collision(i).get_normal().y > 0.7:
			var h := Vector2(velocity.x, velocity.z).move_toward(Vector2.ZERO, ground_friction * delta)
			velocity.x = h.x
			velocity.z = h.y
			return
