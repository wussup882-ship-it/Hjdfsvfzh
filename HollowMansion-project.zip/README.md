# The Hollow Mansion (Quest VR, Godot 4.4.1)

A Gorilla Tag-style horror game. Find 3 keys, unlock the front door, run outside.
The Hollow patrols the mansion, walks toward noises (slap walls hard and it hears you)
and sprints at you if it sees you. If it catches you, you restart at the front hall.

## Get the APK (GitHub does the building)
1. Make a new GitHub repository.
2. Upload EVERYTHING from this folder, including the hidden `.github` folder.
3. Open the **Actions** tab. "Build Hollow Mansion APK" runs by itself (or press **Run workflow**).
4. When it turns green (about 10 minutes), open **Releases -> Latest build** and download
   `HollowMansion.apk` (or the `.zip` with the APK inside).
5. Sideload on your Quest (SideQuest, or `adb install HollowMansion.apk`).
   It shows up under **Unknown Sources** in the app library.

## Files
- `player.gd`   - your Unity GorillaLocomotion `Player.cs` ported to Godot, plus the VR rig
- `mansion.gd`  - builds the mansion, furniture, stairs, lights, locked front door
- `monster.gd`  - the Hollow: model, animation, patrol / investigate / search / hunt
- `main.gd`     - VR start-up, keys, win and lose rules, wrist HUD
- `export_presets.cfg`, `.github/workflows/build-apk.yml` - Quest APK build
