class_name Mansion
extends Node3D
## The whole mansion, built from boxes. Same layout as the 3D preview.
## Plan units: 1 unit = 5 cm. Plan x 40..640, y 56..276 -> metres around (0,0).

const S := 0.05
const H := 3.2       # floor height
const T := 0.2       # wall thickness
const DH := 2.3      # door height

const WALL := 0xcfc6b2
const WD := 0x6b4a32
const WL := 0x8a6a50

# Furniture: [x, y, width, depth, height, colour] in plan units.
const FURN_0: Array = [
	[48, 58, 200, 8, 2.4, WD], [42, 70, 8, 60, 2.4, WD], [110, 92, 44, 26, 0.75, WL], [70, 120, 24, 24, 0.9, 0x8b3a3a],
	[95, 200, 100, 30, 0.75, WD], [105, 190, 8, 8, 0.9, WL], [125, 190, 8, 8, 0.9, WL], [145, 190, 8, 8, 0.9, WL], [165, 190, 8, 8, 0.9, WL],
	[105, 232, 8, 8, 0.9, WL], [125, 232, 8, 8, 0.9, WL], [145, 232, 8, 8, 0.9, WL], [165, 232, 8, 8, 0.9, WL], [44, 200, 10, 50, 1.0, WD],
	[470, 60, 80, 22, 0.8, 0x4a5a7a], [470, 60, 80, 6, 1.1, 0x4a5a7a], [480, 95, 60, 20, 0.4, WD], [580, 100, 24, 24, 0.9, 0x4a5a7a], [628, 90, 10, 36, 1.6, 0x555555],
	[430, 170, 160, 12, 0.9, 0xcfcfc9], [626, 172, 10, 96, 0.9, 0xcfcfc9], [500, 210, 80, 24, 0.9, WL], [600, 258, 20, 16, 1.9, 0xdcdcdc],
	[305, 80, 70, 70, 0.03, 0x7a2d2d],
	[100, 84, 64, 42, 0.03, 0x6b2d3a], [460, 86, 100, 44, 0.03, 0x3b4a6a], [85, 190, 120, 50, 0.02, 0x5a3a3a],
]
const FURN_1: Array = [
	[46, 70, 40, 36, 0.6, 0x6a4d6b], [44, 70, 4, 36, 1.2, WD], [150, 58, 60, 10, 2.2, WD], [46, 110, 10, 10, 0.5, WD],
	[44, 230, 34, 40, 0.5, 0x3b6a9a], [180, 250, 50, 18, 0.75, WD], [196, 232, 10, 10, 0.9, WL], [150, 170, 50, 8, 2.0, WD],
	[440, 58, 160, 8, 2.4, WD], [500, 80, 50, 24, 0.75, WD], [520, 106, 12, 12, 0.9, WL], [590, 110, 24, 24, 0.9, 0x4a5a7a],
	[430, 172, 40, 12, 0.9, WD], [570, 250, 60, 22, 0.6, 0xf1efe8], [440, 256, 14, 14, 0.4, 0xf1efe8],
	[90, 75, 80, 60, 0.03, 0x5a4a7a],
]

var world := StaticBody3D.new()
var front_door: StaticBody3D
var lights: Array = []   # [OmniLight3D, base_energy]
var _mats := {}


static func X(x: float) -> float:
	return (x - 340.0) * S


static func Z(y: float) -> float:
	return (y - 166.0) * S


func mat(color: int, emissive := 0.0) -> StandardMaterial3D:
	var key := "%d_%d" % [color, int(emissive * 100.0)]
	if not _mats.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = Color.hex((color << 8) | 0xff)
		m.roughness = 0.95
		if emissive > 0.0:
			m.emission_enabled = true
			m.emission = m.albedo_color
			m.emission_energy_multiplier = emissive
		_mats[key] = m
	return _mats[key]


func box(size: Vector3, pos: Vector3, color: int, solid := true, emissive := 0.0, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat(color, emissive)
	mi.position = pos
	(parent if parent != null else self).add_child(mi)
	if solid and parent == null:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		cs.position = pos
		world.add_child(cs)
	return mi


func solid_only(size: Vector3, pos: Vector3) -> void:
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	cs.position = pos
	world.add_child(cs)


func _seg(hz: bool, lo: float, hi: float, k: float, y0: float, h: float) -> void:
	if hi - lo < 0.01:
		return
	var length := (hi - lo) * S
	var mid := (lo + hi) / 2.0
	if hz:
		box(Vector3(length, h, T), Vector3(X(mid), y0 + h / 2.0, Z(k)), WALL)
	else:
		box(Vector3(T, h, length), Vector3(X(k), y0 + h / 2.0, Z(mid)), WALL)


func wall(x1: float, y1: float, x2: float, y2: float, gaps: Array, lvl: int) -> void:
	var hz := is_equal_approx(y1, y2)
	var a := x1 if hz else y1
	var b := x2 if hz else y2
	var k := y1 if hz else x1
	var y0 := lvl * H
	var p := a
	for g in gaps:
		_seg(hz, p, float(g[0]), k, y0, H)
		_seg(hz, float(g[0]), float(g[1]), k, y0 + DH, H - DH)
		p = float(g[1])
	_seg(hz, p, b, k, y0, H)


func slab(x: float, y: float, w: float, d: float, color: int, lvl: int) -> void:
	box(Vector3(w * S, 0.2, d * S), Vector3(X(x + w / 2.0), lvl * H - 0.1, Z(y + d / 2.0)), color)


func furn(lvl: int, f: Array) -> void:
	var ht := float(f[4])
	box(Vector3(float(f[2]) * S, ht, float(f[3]) * S),
		Vector3(X(float(f[0]) + float(f[2]) / 2.0), lvl * H + ht / 2.0, Z(float(f[1]) + float(f[3]) / 2.0)),
		int(f[5]), ht > 0.05)


func window(lvl: int, x: float, y: float, hz: bool) -> void:
	var size := Vector3(1.8, 1.2, T + 0.04) if hz else Vector3(T + 0.04, 1.2, 1.8)
	box(size, Vector3(X(x), lvl * H + 1.6, Z(y)), 0x4a6a8c, false, 0.6)


func pic(lvl: int, x: float, color: int) -> void:
	box(Vector3(1.4, 1.1, 0.05), Vector3(X(x), lvl * H + 1.9, -5.38), 0x4a3a2a, false)
	box(Vector3(1.2, 0.9, 0.06), Vector3(X(x), lvl * H + 1.9, -5.37), color, false)


func plant(lvl: int, x: float, y: float) -> void:
	var pot := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.25
	cm.bottom_radius = 0.2
	cm.height = 0.5
	cm.radial_segments = 10
	pot.mesh = cm
	pot.material_override = mat(0x4a3a2a)
	pot.position = Vector3(X(x), lvl * H + 0.25, Z(y))
	add_child(pot)
	var leaves := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.4
	sm.height = 0.8
	sm.radial_segments = 10
	sm.rings = 5
	leaves.mesh = sm
	leaves.material_override = mat(0x4f8a3a)
	leaves.position = Vector3(X(x), lvl * H + 0.85, Z(y))
	add_child(leaves)


func add_light(pos: Vector3, color: Color, energy: float, rng: float) -> void:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = color
	l.light_energy = energy
	l.omni_range = rng
	add_child(l)
	lights.append([l, energy])


func build() -> void:
	world.name = "World"
	add_child(world)

	# ---- walls
	var common: Array = [
		[40, 56, 640, 56, []], [40, 56, 40, 276, []], [640, 56, 640, 276, []],
		[40, 166, 260, 166, [[55, 85]]], [420, 166, 640, 166, [[595, 625]]],
	]
	for lvl in 2:
		for w in common:
			wall(w[0], w[1], w[2], w[3], w[4], lvl)
	wall(40, 276, 640, 276, [[320, 360]], 0)
	wall(40, 276, 640, 276, [], 1)
	wall(260, 56, 260, 276, [[128, 152], [238, 262]], 0)
	wall(420, 56, 420, 276, [[128, 152], [238, 262]], 0)
	wall(260, 56, 260, 276, [[136, 158], [210, 232]], 1)
	wall(420, 56, 420, 276, [[136, 158], [210, 232]], 1)

	# ---- floors
	for r in [[40, 56, 220, 110, 0x7a5c45], [40, 166, 220, 110, 0x8a6a50], [420, 56, 220, 110, 0x7a5c45], [420, 166, 220, 110, 0x7f7f78], [260, 56, 160, 220, 0x5c5b57]]:
		slab(r[0], r[1], r[2], r[3], r[4], 0)
	for r in [[40, 56, 220, 110, 0x6a4d6b], [40, 166, 220, 110, 0x8a6a50], [420, 56, 220, 110, 0x7a5c45], [420, 166, 220, 110, 0x7f9aa0], [260, 56, 50, 220, 0x5c5b57], [370, 56, 50, 220, 0x5c5b57], [310, 56, 60, 100, 0x5c5b57], [310, 256, 60, 20, 0x5c5b57]]:
		slab(r[0], r[1], r[2], r[3], r[4], 1)

	# ---- stairs (solid steps) and railings round the stairwell
	for i in 16:
		box(Vector3(3.0, 0.2 * (i + 1), 0.3125), Vector3(0, 0.1 * (i + 1), 4.5 - (i + 0.5) * 0.3125), 0xb08968)
	box(Vector3(0.08, 1.0, 5.0), Vector3(-1.6, H + 0.5, 2.0), WD)
	box(Vector3(0.08, 1.0, 5.0), Vector3(1.6, H + 0.5, 2.0), WD)
	box(Vector3(3.2, 1.0, 0.08), Vector3(0, H + 0.5, 4.55), WD)

	# ---- furniture
	for f in FURN_0:
		furn(0, f)
	for f in FURN_1:
		furn(1, f)

	# ---- windows, paintings, plants
	var wins := [[[500, 580], [100, 200, 500, 580], [148], [146, 220]], [[100, 620], [100, 200, 500, 580], [140, 220], [110, 220]]]
	for lvl in 2:
		var w: Array = wins[lvl]
		for x in w[0]:
			window(lvl, x, 56, true)
		for x in w[1]:
			window(lvl, x, 276, true)
		for y in w[2]:
			window(lvl, 40, y, false)
		for y in w[3]:
			window(lvl, 640, y, false)
	var cols := [0x8b3a3a, 0x3b6a9a, 0x6a8f4a]
	for i in 3:
		pic(0, 290 + 50 * i, cols[i])
		pic(1, 290 + 50 * i, cols[i])
	pic(0, 510, 0x8a6a50)
	for x in [272, 408]:
		plant(0, x, 266)
		plant(1, x, 266)
	plant(0, 630, 64)

	# ---- roof, porch, lawn, path
	box(Vector3(31, 0.3, 12), Vector3(0, 2.0 * H + 0.15, 0), 0x5a4a44)
	box(Vector3(5.2, 0.25, 2.6), Vector3(0, H + 0.1, 6.8), WALL)
	for x in [-2.2, 2.2]:
		box(Vector3(0.44, H, 0.44), Vector3(x, H / 2.0, 7.6), WALL)
	box(Vector3(90, 0.2, 70), Vector3(0, -0.15, 0), 0x2f4a30)
	box(Vector3(2.4, 0.1, 9), Vector3(0, -0.05, 10), 0x77776f)
	# invisible fence so nobody launches themselves off the map
	solid_only(Vector3(90, 30, 1), Vector3(0, 15, -35.5))
	solid_only(Vector3(90, 30, 1), Vector3(0, 15, 35.5))
	solid_only(Vector3(1, 30, 70), Vector3(-45.5, 15, 0))
	solid_only(Vector3(1, 30, 70), Vector3(45.5, 15, 0))

	# ---- locked front door (removed when you have all the keys)
	front_door = StaticBody3D.new()
	front_door.collision_layer = 1
	var dcs := CollisionShape3D.new()
	var dsh := BoxShape3D.new()
	dsh.size = Vector3(2.0, DH, 0.14)
	dcs.shape = dsh
	front_door.add_child(dcs)
	var dmi := MeshInstance3D.new()
	var dbm := BoxMesh.new()
	dbm.size = dsh.size
	dmi.mesh = dbm
	dmi.material_override = mat(0x4a2e1c)
	front_door.add_child(dmi)
	front_door.position = Vector3(0, DH / 2.0, Z(276))
	add_child(front_door)

	# ---- lights (kept few and cheap: Quest has a small GPU)
	var warm := Color(1.0, 0.78, 0.5)
	add_light(Vector3(0, H - 0.9, -3), warm, 1.4, 11.0)
	var ch := MeshInstance3D.new()
	var csm := SphereMesh.new()
	csm.radius = 0.3
	csm.height = 0.6
	csm.radial_segments = 10
	csm.rings = 5
	ch.mesh = csm
	ch.material_override = mat(0xffd27a, 2.0)
	ch.position = Vector3(0, H - 0.9, -3)
	add_child(ch)
	for lvl in 2:
		for c in [[150, 111], [150, 221], [530, 111], [530, 221]]:
			add_light(Vector3(X(c[0]), lvl * H + 2.7, Z(c[1])), Color(0.9, 0.75, 0.55), 0.8, 6.0)


func flicker(delta: float, monster_pos: Vector3) -> void:
	for e in lights:
		var l: OmniLight3D = e[0]
		var base: float = e[1]
		var near := l.global_position.distance_to(monster_pos) < 9.0
		if near and randf() < 8.0 * delta:
			l.light_energy = base * randf_range(0.0, 0.8)
		else:
			l.light_energy = lerpf(l.light_energy, base, minf(1.0, delta * 6.0))


# ------------------------------------------------------------ game positions

func _pts(list: Array, h: float) -> Array[Vector3]:
	var r: Array[Vector3] = []
	for a in list:
		r.append(Vector3(X(a[0]), h if a.size() < 3 else a[2], Z(a[1])))
	return r


func spawn_path() -> Array[Vector3]:
	return _pts([[560, 150, H], [440, 147, H], [395, 147, H], [340, 152, H], [340, 256, 0.0], [340, 262, 0.0]], 0.0)


func loop_points() -> Array[Vector3]:
	return _pts([[340, 110], [290, 140], [230, 148], [75, 150], [70, 250], [230, 250], [290, 250], [290, 264],
		[390, 264], [390, 250], [440, 250], [600, 250], [610, 180], [610, 140], [430, 140], [395, 140]], 0.0)


func key_positions() -> Array[Vector3]:
	return [
		Vector3(X(132), 0.9, Z(105)),            # library table
		Vector3(X(525), H + 0.9, Z(92)),         # study desk (upstairs)
		Vector3(X(540), 0.98, Z(222)),           # kitchen island
	]


func player_spawn() -> Vector3:
	return Vector3(X(405), 0.05, Z(190))
